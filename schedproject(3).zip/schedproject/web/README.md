# WEB APP

## Features

-   **Calendar Management**: Create and manage global and formation-specific calendars.
-   **Course Management**: Organize courses, their specialities, and associated modalities.
-   **Resource Management**: Handle rooms, teachers, and other resources efficiently.
-   **Rule-based Scheduling**: Define and apply complex scheduling rules using a flexible rule engine.
-   **Data Labeling System**: Label and categorize data for better organization and analysis.
