from interface_web_app import InterfacesWebApp

iwa = InterfacesWebApp(host="http://db-api-controller").run()
