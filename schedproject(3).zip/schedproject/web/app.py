from interface_web_app import InterfacesWebApp

iwa = InterfacesWebApp(host="http://localhost", port=5000).run()
