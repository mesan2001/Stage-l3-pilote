import { AbstractModel } from "./AbstractModel.js";

export class Step extends AbstractModel {
    static tableName = "steps";
}
