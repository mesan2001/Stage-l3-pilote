import { AbstractModel } from "./AbstractModel.js";

export class Classroom extends AbstractModel {
    static tableName = "classrooms";
}
