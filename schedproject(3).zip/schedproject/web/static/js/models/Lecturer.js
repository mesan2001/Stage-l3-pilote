import { AbstractModel } from "./AbstractModel.js";

export class Lecturer extends AbstractModel {
    static tableName = "lecturers";
}
