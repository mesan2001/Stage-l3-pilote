import subprocess
import time

# Example 1: Using subprocess.run to execute sleep command
print("Running sleep command for 2 seconds...")
subprocess.run(["sleep", "2"])
print("Sleep completed")

# Example 2: Using subprocess.Popen for non-blocking sleep
print("\nStarting non-blocking sleep for 3 seconds...")
process = subprocess.Popen(["sleep", "3"])
print("Sleep process started with PID:", process.pid)
print("Doing other work while sleep is running...")
time.sleep(1)
print("Waiting for sleep process to complete...")
process.wait()
print("Sleep process completed")

# Example 3: With timeout
print("\nRunning sleep with timeout...")
try:
    # This will timeout after 1 second while the sleep command tries to run for 5 seconds
    subprocess.run(["sleep", "5"], timeout=1)
except subprocess.TimeoutExpired:
    print("Process timed out as expected")
