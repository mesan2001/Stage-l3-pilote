/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./web/**/*.html", "./web/**/*.js", "./web/**/*.py"],
    theme: {
        extend: {},
    },
    plugins: [],
};
